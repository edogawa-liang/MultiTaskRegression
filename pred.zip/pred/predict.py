import pandas as pd
import joblib
import os
from prep.load import load_data


# 載入資料做預處理，並使用已訓練的模型進行預測。
def predict_newdata(target_column, model_path, data_path, sheet_name=None):
    
    # 載入新資料
    test_new = load_data(data_path, sheet_name)
    
    # 從指定路徑加載模型
    model_pipeline = joblib.load(model_path)

    # 加載模型
    preprocessor = model_pipeline.named_steps['preprocessor']
    model = model_pipeline.named_steps['model_training']
    
    # 確認目標欄位是否存在於資料中。若存在，將其刪除不使用
    X_test = test_new.drop(columns=[target_column], errors='ignore')

    # 對測試資料進行預處理
    X_test_preprocessed = preprocessor.transform(X_test)

    # 使用模型進行預測
    y_pred = model.predict(X_test_preprocessed)

    # 將預測結果合併回原始資料
    new_prediction = pd.concat([X_test.reset_index(drop=True), 
                        pd.Series(y_pred, name=f'{target_column}_Predicted').reset_index(drop=True)], axis=1)
    
    # 將含預測結果回傳CSV
    output_path = os.path.join(os.getcwd(), "new_prediction.csv")
    new_prediction.to_csv(output_path, index=False, encoding='utf-8-sig')

    print(f"預測結果成功保存於 {output_path}。")


# 使用範例
if __name__ == "__main__":
    data_path = input("請輸入資料路徑：").strip()
    sheet_name = input("若資料為Excel檔案, 請輸入工作表名稱 (若為csv或使用Excel第一個工作表，請直接按Enter): ").strip()
    target_column = input("請輸入目標欄位名稱: ").strip()
    model_path = input("請輸入模型路徑：").strip()

    predict_newdata(target_column, model_path, data_path, sheet_name)
